package com.hvc.rockmusic.ui.fragment;

import android.support.v4.app.Fragment;


public class BaseFragment extends Fragment {
}
